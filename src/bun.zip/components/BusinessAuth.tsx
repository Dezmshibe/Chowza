import { useState, type FormEvent } from 'react';
import { supabase } from '../lib/supabase';

type BusinessAuthProps = {
  onBack: () => void;
  onAuthenticated: () => void;
};

export function BusinessAuth({
  onBack,
  onAuthenticated,
}: BusinessAuthProps) {
  const [mode, setMode] = useState<'login' | 'signup' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function createBusinessSlug(name: string, userId: string) {
    const baseSlug =
      name
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '') || 'business';

    return `${baseSlug}-${userId.slice(0, 8)}`;
  }

  async function ensureBusinessProfile(
    user: {
      id: string;
      user_metadata?: Record<string, unknown> | null;
    },
    fallbackBusinessName = '',
  ) {
    const { data: existingBusiness, error: lookupError } =
      await supabase
        .from('businesses')
        .select('id')
        .eq('owner_id', user.id)
        .maybeSingle();

    if (lookupError) {
      throw lookupError;
    }

    if (existingBusiness) {
      return existingBusiness.id;
    }

    const metadataBusinessName =
      typeof user.user_metadata?.business_name === 'string'
        ? user.user_metadata.business_name.trim()
        : '';

    const name = fallbackBusinessName.trim() || metadataBusinessName;

    if (!name) {
      throw new Error(
        'Your account is ready, but your business profile still needs to be set up.',
      );
    }

    const slug = createBusinessSlug(name, user.id);

    const { data: business, error: insertError } =
      await supabase
        .from('businesses')
        .insert({
          owner_id: user.id,
          name,
          slug,
          description: '',
          is_published: false,
        })
        .select('id')
        .single();

    if (insertError) {
      throw insertError;
    }

    return business.id;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    // Prevent accidental double submission.
    if (loading) {
      return;
    }

    setMessage('');
    setError('');
    setLoading(true);

    try {
      const cleanEmail = email.trim();

      if (!cleanEmail) {
        throw new Error('Please enter your email address.');
      }

      // =========================================================
      // BUSINESS SIGNUP
      // =========================================================
      if (mode === 'signup') {
        const cleanBusinessName = businessName.trim();

        if (cleanBusinessName.length < 2) {
          throw new Error('Please enter your business name.');
        }

        if (cleanBusinessName.length > 100) {
          throw new Error('Business name must be 100 characters or fewer.');
        }

        

        const { data, error: signupError } =
          await supabase.auth.signUp({
            email: cleanEmail,
            password,
            options: {
              emailRedirectTo: window.location.origin,
              data: {
                business_name: cleanBusinessName,
              },
            },
          });

        

        if (signupError) {
          throw signupError;
        }

        // ---------------------------------------------------------
        // Signup completed immediately and Supabase created a
        // session. This is the ONLY situation where we mark the
        // account as a brand-new business signup.
        // ---------------------------------------------------------
        if (data.session && data.user) {
          await ensureBusinessProfile(
            data.user,
            cleanBusinessName,
          );

          setMessage(
            'Your account is ready. Loading your business account...'
          );

          sessionStorage.setItem(
            'chowza_new_business_signup',
            'true'
          );

          

          

          

          window.setTimeout(() => {
            onAuthenticated();
          }, 100);
        } else {
          // -------------------------------------------------------
          // Supabase requires email confirmation.
          // Do NOT mark this as an active new-business session.
          // -------------------------------------------------------
          sessionStorage.removeItem(
            'chowza_new_business_signup'
          );

          setMessage(
            'Registration received! Check your email and click the verification link before logging in.'
          );
        }

        return;
      }

      // =========================================================
      // BUSINESS LOGIN
      // =========================================================
      if (mode === 'login') {
        

        const {
          data,
          error: loginError,
        } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password,
        });

        

        if (loginError) {
          throw loginError;
        }

        if (!data.user || !data.session) {
          throw new Error(
            'Supabase accepted the login but did not return an active session.'
          );
        }

        

        // Confirm that the browser can read the authenticated session.
        const {
          data: { user },
          error: userError,
        } = await supabase.auth.getUser();

        if (userError) {
          

          throw userError;
        }

        if (!user) {
          throw new Error(
            'Login succeeded, but Chowza could not verify the active user session.'
          );
        }

        await ensureBusinessProfile(user);

        

        // IMPORTANT:
        // Normal login must NEVER trigger the new-business banner.
        sessionStorage.removeItem(
          'chowza_new_business_signup'
        );

        setMessage(
          'Login successful. Loading your account...'
        );

        // Give React a moment to update the auth/session state,
        // then tell App.tsx to open BusinessPortalGate.
        window.setTimeout(() => {
          

          onAuthenticated();
        }, 100);

        return;
      }

      // =========================================================
      // PASSWORD RESET
      // =========================================================
      

      const { error: resetError } =
        await supabase.auth.resetPasswordForEmail(
          cleanEmail,
          {
            redirectTo: `${window.location.origin}/reset-password`,
          }
        );

      if (resetError) {
        throw resetError;
      }

      setMessage(
        'If the email is registered, a password-reset link will be sent.'
      );
    } catch (err) {
      

      setError(
        err instanceof Error
          ? err.message
          : 'Something went wrong. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#F7FAF7] px-4 py-10 flex items-center justify-center">
      <section className="w-full max-w-md rounded-2xl border border-[#E1EAE3] bg-white p-6 shadow-sm sm:p-8">

        <button
          type="button"
          onClick={onBack}
          className="mb-6 text-sm font-semibold text-[#166534] hover:underline"
        >
          ← Back to Chowza
        </button>

        <div className="mb-6">
          <p className="text-sm font-bold uppercase tracking-widest text-[#166534]">
            Chowza for Business
          </p>

          <h1 className="mt-2 text-3xl font-extrabold text-[#17201A]">
            {mode === 'signup'
              ? 'Create your account'
              : mode === 'reset'
                ? 'Reset your password'
                : 'Welcome back'}
          </h1>

          <p className="mt-2 text-sm leading-6 text-[#6B6258]">
            {mode === 'signup'
              ? 'Create an account to start setting up your business.'
              : mode === 'reset'
                ? 'Enter your email to request a password-reset link.'
                : 'Log in to access your business account.'}
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-4"
        >
          {mode === 'signup' && (
            <div>
              <label
                htmlFor="business-name"
                className="mb-1.5 block text-sm font-semibold text-[#17201A]"
              >
                Business name
              </label>

              <input
                id="business-name"
                type="text"
                autoComplete="organization"
                required
                minLength={2}
                maxLength={100}
                value={businessName}
                onChange={(event) =>
                  setBusinessName(event.target.value)
                }
                placeholder="e.g. Makhulu's Kitchen"
                className="w-full rounded-xl border border-[#D7E2DA] px-4 py-3 text-sm outline-none focus:border-[#166534] focus:ring-2 focus:ring-[#166534]/15"
              />
            </div>
          )}

          <div>
            <label
              htmlFor="business-email"
              className="mb-1.5 block text-sm font-semibold text-[#17201A]"
            >
              Email address
            </label>

            <input
              id="business-email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) =>
                setEmail(event.target.value)
              }
              placeholder="you@example.com"
              className="w-full rounded-xl border border-[#D7E2DA] px-4 py-3 text-sm outline-none focus:border-[#166534] focus:ring-2 focus:ring-[#166534]/15"
            />
          </div>

          {mode !== 'reset' && (
            <div>
              <label
                htmlFor="business-password"
                className="mb-1.5 block text-sm font-semibold text-[#17201A]"
              >
                Password
              </label>

              <input
                id="business-password"
                type="password"
                autoComplete={
                  mode === 'signup'
                    ? 'new-password'
                    : 'current-password'
                }
                minLength={6}
                required
                value={password}
                onChange={(event) =>
                  setPassword(event.target.value)
                }
                placeholder={
                  mode === 'signup'
                    ? 'At least 6 characters'
                    : 'Enter your password'
                }
                className="w-full rounded-xl border border-[#D7E2DA] px-4 py-3 text-sm outline-none focus:border-[#166534] focus:ring-2 focus:ring-[#166534]/15"
              />
            </div>
          )}

          {error && (
            <p
              role="alert"
              className="rounded-lg bg-red-50 p-3 text-sm text-red-700"
            >
              {error}
            </p>
          )}

          {message && (
            <p
              role="status"
              className="rounded-lg bg-green-50 p-3 text-sm text-green-800"
            >
              {message}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-[#15803D] px-4 py-3 font-bold text-white transition hover:bg-[#14532D] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading
              ? 'Please wait…'
              : mode === 'signup'
                ? 'Create account'
                : mode === 'reset'
                  ? 'Send reset link'
                  : 'Log in'}
          </button>
        </form>

        <div className="mt-5 flex flex-col items-center gap-3 text-sm">

          {mode === 'login' && (
            <>
              <button
                type="button"
                onClick={() => {
                  setMode('reset');
                  setMessage('');
                  setError('');
                }}
                className="font-semibold text-[#166534] hover:underline"
              >
                Forgot password?
              </button>

              <p className="text-[#6B6258]">
                New to Chowza?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    setMessage('');
                    setError('');
                  }}
                  className="font-bold text-[#166534] hover:underline"
                >
                  Create an account
                </button>
              </p>
            </>
          )}

          {mode !== 'login' && (
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setMessage('');
                setError('');
              }}
              className="font-semibold text-[#166534] hover:underline"
            >
              Back to login
            </button>
          )}
        </div>

        <p className="mt-6 text-center text-xs leading-5 text-[#8A8177]">
          Your account is separate from the Chowza demo businesses.
          Never share your password with anyone.
        </p>

      </section>
    </main>
  );
}





